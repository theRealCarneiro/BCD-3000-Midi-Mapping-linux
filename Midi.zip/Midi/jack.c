#include <stdlib.h>

void master(int status, int channel){
	if(status == 1){
    	if(channel == 0){
			system("jack_connect main:front-left system:playback_1");
    		system("jack_connect main:front-right system:playback_2");
		} 
		else if(channel == 1){
			system("jack_connect music:front-left system:playback_1");
    		system("jack_connect music:front-right system:playback_2");
		}
	} 
	else if (status == 0) {
		if(channel == 0){
			system("jack_disconnect main:front-left system:playback_1");
    		system("jack_disconnect main:front-right system:playback_2");
		} 
		else if(channel == 1){
			system("jack_disconnect music:front-left system:playback_1");
    		system("jack_disconnect music:front-right system:playback_2");
		}		
	}
}

void phone(int status, int channel){
	if(status == 1){
    	if(channel == 0){
			system("jack_connect main:front-left system:playback_4");
    		system("jack_connect main:front-right system:playback_3");
		} 
		else if(channel == 1){
			system("jack_connect music:front-left system:playback_4");
    		system("jack_connect music:front-right system:playback_3");
		}
	} 
	else if (status == 0) {
		if(channel == 0){
			system("jack_disconnect main:front-left system:playback_4");
    		system("jack_disconnect main:front-right system:playback_3");
		} 
		else if(channel == 1){
			system("jack_disconnect music:front-left system:playback_4");
    		system("jack_disconnect music:front-right system:playback_3");
		}		
	}
}

void midiJack(int key, int led){
	if(key == 24){
		if(led == 127){
			master(1, 0);
		} 
		else master(0, 0);
	}
	else if(key == 23){
		if(led == 127){
			phone(1, 0);
		} 
		else phone(0, 0);
	}
	else if(key == 16){
		if(led == 127){
			master(1, 1);
		} 
		else master(0, 1);
	}
	else if(key == 15){
		if(led == 127){
			phone(1, 1);
		} 
		else phone(0, 1);
	}	
}