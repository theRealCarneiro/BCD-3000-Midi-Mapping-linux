#!/bin/bash
nohup ./BCD &
